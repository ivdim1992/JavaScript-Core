result.mapSort = require('./mapSort');

let map = new Map();
map.set(3,'Gosho')
map.set(1,'ivo');
map.set(5,'Ivan')
console.log(result(map))