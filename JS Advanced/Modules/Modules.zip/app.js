let Person = require('./person').Person;

result.Person = Person;
